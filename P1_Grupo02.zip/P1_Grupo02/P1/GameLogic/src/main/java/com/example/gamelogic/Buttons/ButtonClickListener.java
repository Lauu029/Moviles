package com.example.gamelogic.Buttons;

public interface ButtonClickListener {
    void onClick();
}
