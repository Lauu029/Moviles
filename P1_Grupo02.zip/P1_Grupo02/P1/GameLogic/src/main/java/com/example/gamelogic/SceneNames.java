package com.example.gamelogic;

public enum SceneNames {
    MENU,
    LEVEL,
    GAME,
    FINAL
}
