package com.example.engine;

public interface ISound {
}
