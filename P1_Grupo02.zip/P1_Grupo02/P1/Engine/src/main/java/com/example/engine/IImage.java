package com.example.engine;

public interface IImage {
    int getWidth(); //Devuelve el ancho de una imagen
    int getHeight(); //Devuelve el alto de una imagen

}
