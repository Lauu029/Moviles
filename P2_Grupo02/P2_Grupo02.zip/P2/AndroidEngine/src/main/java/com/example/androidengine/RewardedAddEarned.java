package com.example.androidengine;
//interfaz para que cuando acabe un anuncio te lleve al metodo implementado
public interface RewardedAddEarned {
    void OnRewardedEarned();
}
