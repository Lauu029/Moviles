package com.example.androidengine;

import android.graphics.Bitmap;

public interface ImageProcessingCallback {
    void processImage(Bitmap bitmap);
}
