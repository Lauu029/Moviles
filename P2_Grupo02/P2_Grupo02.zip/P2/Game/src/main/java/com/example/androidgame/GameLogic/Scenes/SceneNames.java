package com.example.androidgame.GameLogic.Scenes;

public enum SceneNames {
    MENU ,
    DIFFICULTY,
    GAME,
    WORLD,
    FINAL,
    WORLD_FINAL,
    SHOP
}
