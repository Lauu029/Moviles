package com.example.androidgame.GameLogic.Buttons;

public interface ButtonClickListener {
    void onClick();
}
