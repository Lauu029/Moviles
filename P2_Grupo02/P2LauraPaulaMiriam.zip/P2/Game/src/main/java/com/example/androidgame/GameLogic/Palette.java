package com.example.androidgame.GameLogic;

public class Palette {
    int backgroundColor;
    int buttonColor;
    int textColor;
    int lineColor;
}
