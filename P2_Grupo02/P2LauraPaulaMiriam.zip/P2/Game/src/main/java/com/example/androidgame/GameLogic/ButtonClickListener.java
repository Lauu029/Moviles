package com.example.androidgame.GameLogic;

public interface ButtonClickListener {
    void onClick();
}
