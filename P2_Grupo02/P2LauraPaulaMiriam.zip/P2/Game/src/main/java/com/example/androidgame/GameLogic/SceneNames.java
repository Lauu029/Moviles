package com.example.androidgame.GameLogic;

public enum SceneNames {
    MENU ,
    DIFFICULTY,
    LEVEL,
    GAME,
    WORLD,
    FINAL,
    WORLD_FINAL,
    SHOP
}
