package com.example.androidengine;

public interface RewardedAddEarned {
    void OnRewardedEarned();
}
