package com.example.gamelogic;

public enum LevelDifficulty {
    FACIL,
    MEDIO,
    DIFICIL,
    IMPOSIBLE
}
