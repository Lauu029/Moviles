package com.example.gamelogic.Scenes;

public enum SceneNames {
    MENU,
    LEVEL,
    DIFFICULTY,
    GAME,
    FINAL
}
